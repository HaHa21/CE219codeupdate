"""
Routes and views for the bottle application.
"""
from config import *
from html import entities
from bottle import *
from entities import *
from pony.orm.integration.bottle_plugin import PonyPlugin
install(PonyPlugin())

import datetime


@route('/')

@view('index')
def index():
	 return template('index')

@route('/books')

def all_books():

	 books = select(b for b in Book)
	 return template('books/index', books = books)

@route('/books/<id>/')

def showbook(id):
	book = Book[id]
	
	return template( 'books/showbook', book = book)
	
@route('/books/new')

def new_books():
   
	authorlist = select(a for a in Author)
	publisherlist = select(p for p in Publisher)
	genrelist = select(g for g in Genre)
	
	return template('books/addbook', mydate = datetime.date.today(), authorlist = authorlist, publisherlist = publisherlist, genrelist = genrelist)

@route('/books/create', method="POST")
def create_book():
   
	title = request.forms.get('title')
	author = Author.get(id = request.forms.get('author'))
	publisher = Publisher.get(id = request.forms.get('publisher'))
	genre = Genre.get(id = request.forms.get('genre'))
	year = request.forms.get('year')

	print(title, author, publisher, genre, year)

	book = Book(title = title, author = author, publisher = publisher, genre = genre, year = year)
   
	redirect('/')

@route('/books/<id>/edit')

@view('editbooks')
def showbook(id):
   
	book = Book[id]
	return template('books/editbooks', mydate = datetime.date.today(), book = book)

@post('/books/<id>/update')
def update_book(id):
	book = Book[id]
	book.title = request.forms.get('title')
	book.author = Author.get(id = request.forms.get('author'))
	book.publisher = Publisher.get(id = request.forms.get('publisher'))
	book.genre = Genre.get(id = request.forms.getter('genre'))
	book.year = request.forms.get('year')
	redirect('/')

@route('/books/<id>/delete')

def delete_contact(id):
	book = Book[id]
	book.delete()
	redirect('/')

@post('/books/searchbytitle')
def search_books_by_title():
	title = request.forms.get('title')
	title = "%" + title + "%"
	books = Book.select_by_sql("SELECT * FROM Book WHERE title LIKE $title")
	return template('books/index', books=books)

@post('/books/searchbyauthor')
def search_books_by_author():
	author = request.forms.get('author')
	author = "%" + author + "%"
	books = Book.select_by_sql("SELECT * FROM Book WHERE author LIKE $author")
	return template('books/index', books=books)

@post('/books/searchbypublisher')
def search_books_by_publisher():
	publisher = request.forms.get('publisher')
	publisher = "%" + publisher + "%"
	books = Book.select_by_sql("SELECT * FROM Book WHERE publisher LIKE $publisher")
	return template('books/index', books=books)

@route('/authors')

def all_books():

	 authors = select(a for a in Author)
	 return template('author/index', authors = authors)

@route('/authors/new')

def new_books():
   
	authorlist = select(a for a in Author)
  
	return template('author/addauthor', mydate = datetime.date.today(), authorlist = authorlist)

@route('/authors/create', method = "POST")

@view('/author/addauthor')

def author():
	firstname = request.forms.get("firstname")
	lastname = request.forms.get("lastname")

	author = Author(firstname = firstname, lastname = lastname)

	redirect('/')

	return dict(mydate = datetime.date.today())

@route('/authors/<id>/edit')

@view('/author/editauthor')
def showbook(id):
   
	author = Author[id]
	return template('author/editauthor', mydate = datetime.date.today(), author = author)

@post('/authors/<id>/update')
def update_book(id):
	
	author = Author[id]
	author.firstname = request.forms.get('firstname')
	author.lastname = request.forms.get('lastname')
	redirect('/')

@route('/authors/<id>/delete')

def delete_contact(id):
	author = Author[id]
	author.delete()
	redirect('/')

@post('/authors/searchbyname')
def search_authors_by_name():
	name = request.forms.get('name')
	authors = Author.select_by_sql("SELECT * FROM Author WHERE firstname LIKE $name OR lastname LIKE $name")
	return template('author/index', authors=authors)

@route('/publishers')

def all_books():

	 publisher = select(p for p in Publisher)
	 return template('publishers/index', publisher = publisher)

@route('/publishers/new')

def new_publisher():
   
	publisherlist = select(p for p in Publisher)
  
	return template('publishers/addpublisher', mydate = datetime.date.today(), publisherlist = publisherlist)

@route('/publishers/create', method = "POST")

@view('/publishers/addpublisher')

def publisher():
	publishername = request.forms.get("publishername")
	publishercountry = request.forms.get("publishercountry")

	publisher = Publisher(publishername = publishername, publishercountry = publishercountry)

	redirect('/')

	return dict(mydate = datetime.date.today())

@route('/publishers/<id>/edit')

@view('/publishers/editpublisher')
def showpublisher(id):
   
	publisher = Publisher[id]
	return template('publishers/editpublisher', mydate = datetime.date.today(), publisher = publisher)

@post('/publishers/<id>/update')
def update_publisher(id):
	
	publisher = Publisher[id]
	publisher.publishername = request.forms.get('publishername')
	publisher.publishercountry = request.forms.get('publishercountry')
	redirect('/')

@route('/publishers/<id>/delete')

def delete_contact(id):
	publisher = Publisher[id]
	publisher.delete()
	redirect('/')

@post('/publishers/searchbyname')
def search_publishers_by_name():
	name = request.forms.get('name')
	publisher = Publisher.select_by_sql("SELECT * FROM Publisher WHERE publishername LIKE $name")
	return template('publishers/index', publisher=publisher)


@route('/genres')

def all_books():

	 genre = select(g for g in Genre)
	 return template('genres/index', genre = genre)

@route('/genres/new')

def new_genre():
   
	genrelist = select(g for g in Genre)
  
	return template('genres/addgenre', mydate = datetime.date.today(), genrelist = genrelist)

@route('/genres/create', method = "POST")

@view('/genres/addgenre')

def genre():
	name = request.forms.get("name")

	genre = Genre(name = name)

	redirect('/')

	return dict(mydate = datetime.date.today())

@route('/genres/<id>/edit')

@view('/genres/editgenre')
def showgenre(id):
   
	genre = Genre[id]
	return template('genres/editgenre', mydate = datetime.date.today(), genre = genre)

@post('/genres/<id>/update')
def update_genre(id):
	
	genre = Genre[id]
	genre.name = request.forms.get('name')
	redirect('/')

@route('/genres/<id>/delete')

def delete_contact(id):
	genre = Genre[id]
	genre.delete()
	redirect('/')

@post('/genres/searchbyname')
def search_genres_by_name():
	name = request.forms.get('name')
	genre = Genre.select_by_sql("SELECT * FROM Genre WHERE name LIKE $name")
	return template('genres/index', genre=genre)

#

@route('/customers')
def all_customer():
	customer = select(c for c in Customer)
	return template('customers/index', customer=customer)


@route('/customer/<id>/')
def showcustomer(id):
	customer = Customer[id]

	return template('customers/showcustomer', customer=customer)

@route('/customers/new')
def new_customer():
	customerlist = select(c for c in Customer)

	return template('customers/addcustomer', mydate=datetime.date.today(), cutomerlist=customerlist)


@route('/customers/create', method="POST")
@view('/customers/addcustomer')
def customer():
	firstname = request.forms.get("firstname")
	lastname = request.forms.get("lastname")
	phonenumber = request.forms.get("phone")
	address = request.forms.get("address")
	city = request.forms.get("city")
	country = request.forms.get("country")

	customer = Customer(firstname=firstname, lastname=lastname,phonenumber=phonenumber,address=address,city=city,country=country)

	redirect('/customers')

	return dict(mydate=datetime.date.today())


@route('/customers/<id>/edit')
@view('/customers/editcustomer')
def showcustomer(id):
	customer = Customer[id]
	return template('customers/editcustomer', mydate=datetime.date.today(), customer=customer)


@post('/customers/<id>/update')
def update_customer(id):
	customer = Customer[id]
	firstname = request.forms.get("firstname")
	lastname = request.forms.get("lastname")
	phonenumber = request.forms.get("phone")
	address = request.forms.get("address")
	city = request.forms.get("city")
	country = request.forms.get("country")

	commit()

	redirect('/customers')


@route('/customers/<id>/delete')
def delete_customer(id):
	customer = Customer[id]
	customer.delete()
	redirect('/customers')

@post('/customers/searchbyname')
def search_customers_by_name():
	name = request.forms.get('name')
	customer = Customer.select_by_sql("SELECT * FROM Customer WHERE firstname LIKE $name OR lastname LIKE $name")
	return template('customers/index', customer=customer)

@post('/customers/searchbycountry')
def search_customers_by_country():
	country = request.forms.get('country')
	country = "%" + country + "%"
	customer = Customer.select_by_sql("SELECT * FROM Customer WHERE country LIKE $country")
	return template('customers/index', customer=customer)

@route('/orders')
def all_orders():
	orders = select(o for o in Order)
	return template('orders/index', orders = orders)
	
@route('/orders/<id>/')
def showorder(id):
	order=Order[id]
	return template('orders/show_orders', order = order)


def show_orders(id):
	order = Order[id]
	# render the info using the show template for orders
	return dict(order = order)
	
@route('/orders/new_order')
@view('orders/new_order')
def new_order():
	customer = Customer.select()
	book = Book.select()
	return dict( book = book , customer = customer )


@route('/orders/create', method="POST")
def create_order():
# form for the user to input information to create an order
	customers = request.forms.get('customer')
	books = request.forms.get('book')
	dateOfPurchase = request.forms.get ('dateOfPurchase')

	print(customers , books , dateOfPurchase)

	order = Order(customers = customers , books = books , dateOfPurchase = dateOfPurchase)

	redirect('/orders')    
	
@route('/orders/<id>/edit')
@view('orders/edit_order')
def edit_order(id):
#Shows full information about selected order
	order = Order[id]
	customer = Customer.select()
	book = Book.select()
	##DateOfPurchase = DateOfPurchase.select()
	return template( 'orders/edit_order' , order = order, customer = customer, book = book)


@post('/orders/<id>/update')
def update_order(id):
# Updates the selected ID within the order module 
	order = Order[id]
	customers = request.forms.get('customer')
	books = request.forms.get('book')
	order.dateOfPurchase = request.forms.get('dateOfPurchase')

	commit()

	redirect('/orders')


	
@route('/orders/search')
@view('orders/search_order')
def search_order():
	return template('orders/search_order')
	

@route('/orders/searchName', method="POST")
@view('orders/search_results')
def search_name():
	id = request.forms.get('id')
	order = Order.select(lambda p: p.id == id)
	return dict(orders = order)
	
@route('/orders/<id>/delete')
def delete_order(id):
# deletes all information off selected id
	order = Order[id]
	order.delete()
	redirect('/orders')